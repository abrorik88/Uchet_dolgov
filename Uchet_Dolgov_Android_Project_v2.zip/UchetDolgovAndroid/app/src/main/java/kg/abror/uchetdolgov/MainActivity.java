package kg.abror.uchetdolgov;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_SMS=41, REQ_CONTACT=42, REQ_FOLDER=43, REQ_IMPORT=44;
    private WebView web;
    private String pendingPhone, pendingDate, pendingMessage, pendingId;
    private String pendingBackup;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setBackgroundColor(0xFFF3F6FC);
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void js(String script) { runOnUiThread(() -> { if(web!=null) web.evaluateJavascript(script,null); }); }

    public class Bridge {
        @JavascriptInterface public void pickContact() {
            runOnUiThread(() -> {
                try {
                    Intent i=new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    startActivityForResult(i,REQ_CONTACT);
                } catch(Exception e){ js("alert('Не удалось открыть контакты')"); }
            });
        }
        @JavascriptInterface public void scheduleSms(String id,String phone,String dateMillis,String message) {
            pendingId=id; pendingPhone=phone; pendingDate=dateMillis; pendingMessage=message;
            runOnUiThread(() -> {
                if(ContextCompat.checkSelfPermission(MainActivity.this,Manifest.permission.SEND_SMS)==PackageManager.PERMISSION_GRANTED){
                    schedulePending();
                } else ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.SEND_SMS},REQ_SMS);
            });
        }
        @JavascriptInterface public void cancelSms(String id) { SmsReminderReceiver.cancel(MainActivity.this,id); }
        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent,REQ_IMPORT);
            });
        }
        @JavascriptInterface public void chooseDriveFolder() {
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent,REQ_FOLDER);
            });
        }
        @JavascriptInterface public void saveBackup(String json) {
            pendingBackup=json;
            runOnUiThread(() -> saveXlsx(json));
        }
        @JavascriptInterface public String getDriveFolderName() {
            return getPreferences(MODE_PRIVATE).getString("drive_name", "");
        }
    }

    private void schedulePending() {
        try {
            long when=Long.parseLong(pendingDate);
            if(when<=System.currentTimeMillis()){ js("alert('Дата напоминания уже прошла. Выбери будущую дату.')"); return; }
            SmsReminderReceiver.schedule(this,pendingId,pendingPhone,when,pendingMessage);
            js("smsScheduled('"+pendingId.replace("'","\\'")+"')");
            Toast.makeText(this,"SMS-напоминание запланировано",Toast.LENGTH_SHORT).show();
        } catch(Exception e){ js("alert('Не удалось запланировать SMS: "+e.getMessage().replace("'"," ") +"')"); }
    }

    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
        super.onRequestPermissionsResult(requestCode,permissions,results);
        if(requestCode==REQ_SMS){
            if(results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED) schedulePending();
            else js("alert('Без разрешения на отправку SMS автоматические напоминания работать не будут.')");
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(resultCode!=RESULT_OK || data==null) return;
        if(requestCode==REQ_CONTACT){
            Uri uri=data.getData();
            try(Cursor c=getContentResolver().query(uri,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
                if(c!=null && c.moveToFirst()){
                    String name=c.getString(0), phone=c.getString(1);
                    js("contactPicked("+JSONObject.quote(name)+","+JSONObject.quote(phone)+")");
                }
            }catch(Exception e){js("alert('Не удалось прочитать контакт')");}
        } else if(requestCode==REQ_IMPORT){
            try(java.io.InputStream in=getContentResolver().openInputStream(data.getData()); java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
                String json=new String(out.toByteArray(),"UTF-8");
                js("importData("+JSONObject.quote(json)+")");
            }catch(Exception e){js("alert('Не удалось прочитать резервную копию JSON')");}
        } else if(requestCode==REQ_FOLDER){
            Uri tree=data.getData();
            int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(tree,flags);
            getPreferences(MODE_PRIVATE).edit().putString("drive_uri",tree.toString()).putString("drive_name",tree.getLastPathSegment()).apply();
            js("driveFolderChosen("+JSONObject.quote(tree.getLastPathSegment())+")");
        }
    }

    private void saveXlsx(String json){
        String treeString=getPreferences(MODE_PRIVATE).getString("drive_uri",null);
        if(treeString==null){return;}
        try{
            java.io.File tmp=new java.io.File(getCacheDir(),"Uchet_Dolgov.xlsx");
            XlsxWriter.write(new JSONArray(json),tmp);
            DocumentFile dir=DocumentFile.fromTreeUri(this,Uri.parse(treeString));
            if(dir==null || !dir.canWrite()){js("alert('Нет доступа к выбранной папке. Подключи Google Диск заново.')");return;}
            DocumentFile file=dir.findFile("Uchet_Dolgov.xlsx");
            if(file==null) file=dir.createFile("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","Uchet_Dolgov.xlsx");
            if(file==null) throw new Exception("Не удалось создать файл в выбранной папке");
            try(OutputStream out=getContentResolver().openOutputStream(file.getUri(),"wt"); java.io.FileInputStream in=new java.io.FileInputStream(tmp)){
                byte[] buf=new byte[8192]; int n; while((n=in.read(buf))>0) out.write(buf,0,n);
            }
            js("backupSaved("+JSONObject.quote("Uchet_Dolgov.xlsx")+")");
            Toast.makeText(this,"Резервная копия обновлена",Toast.LENGTH_SHORT).show();
        }catch(Exception e){js("alert('Ошибка резервного копирования: "+e.getMessage().replace("'"," ") +"')");}
    }
}
