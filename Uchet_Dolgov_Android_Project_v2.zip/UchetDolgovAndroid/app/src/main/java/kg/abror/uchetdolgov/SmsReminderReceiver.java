package kg.abror.uchetdolgov;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;

public class SmsReminderReceiver extends BroadcastReceiver {
    static final String PREF="sms_reminders";
    @Override public void onReceive(Context context,Intent intent){
        String phone=intent.getStringExtra("phone"), message=intent.getStringExtra("message"), id=intent.getStringExtra("id");
        if(phone==null||message==null||ContextCompat.checkSelfPermission(context,Manifest.permission.SEND_SMS)!=PackageManager.PERMISSION_GRANTED)return;
        try{ SmsManager.getDefault().sendTextMessage(phone,null,message,null,null); }
        catch(Exception ignored){}
        context.getSharedPreferences(PREF,0).edit().remove(id).apply();
    }
    public static void schedule(Context c,String id,String phone,long when,String message){
        Intent i=new Intent(c,SmsReminderReceiver.class).putExtra("id",id).putExtra("phone",phone).putExtra("message",message);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(android.os.Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,pi); else am.set(AlarmManager.RTC_WAKEUP,when,pi);
        c.getSharedPreferences(PREF,0).edit().putString(id,phone+"\n"+when+"\n"+message).apply();
    }
    public static void cancel(Context c,String id){
        Intent i=new Intent(c,SmsReminderReceiver.class);
        PendingIntent pi=PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(pi);
        c.getSharedPreferences(PREF,0).edit().remove(id).apply();
    }
}
