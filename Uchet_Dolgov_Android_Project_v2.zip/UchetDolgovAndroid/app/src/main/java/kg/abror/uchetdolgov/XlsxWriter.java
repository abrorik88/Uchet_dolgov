package kg.abror.uchetdolgov;
import org.json.*;import java.io.*;import java.util.zip.*;
public class XlsxWriter {
 static String esc(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
 static String cell(String col,int row,String val){return "<c r=\""+col+row+"\" t=\"inlineStr\"><is><t>"+esc(val)+"</t></is></c>";}
 public static void write(JSONArray people,File file)throws Exception{
  StringBuilder rows=new StringBuilder();String[] heads={"Имя","Телефон","Первоначальный долг","Дополнительно взято","Получено","Остаток","Срок возврата","Комментарий"};
  String[] cols={"A","B","C","D","E","F","G","H"};
  rows.append("<row r=\"1\">");for(int j=0;j<heads.length;j++)rows.append(cell(cols[j],1,heads[j]));rows.append("</row>");
  for(int i=0;i<people.length();i++){
   JSONObject p=people.getJSONObject(i);JSONArray adds=p.optJSONArray("additions");if(adds==null)adds=new JSONArray();JSONArray pays=p.optJSONArray("payments");if(pays==null)pays=new JSONArray();
   double initial=p.optDouble("amount",0), extra=0,paid=0;for(int k=0;k<adds.length();k++)extra+=adds.optJSONObject(k).optDouble("amount",0);for(int k=0;k<pays.length();k++)paid+=pays.optJSONObject(k).optDouble("amount",0);
   String due=p.optString("dueDate","");String[] vals={p.optString("name"),p.optString("phone"),fmt(initial),fmt(extra),fmt(paid),fmt(Math.max(0,initial+extra-paid)),due,p.optString("note")};
   int r=i+2;rows.append("<row r=\""+r+"\">");for(int j=0;j<vals.length;j++)rows.append(cell(cols[j],r,vals[j]));rows.append("</row>");
  }
  String sheet="<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>"+rows+"</sheetData></worksheet>";
  try(ZipOutputStream z=new ZipOutputStream(new FileOutputStream(file))){put(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");put(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");put(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Долги\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");put(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");put(z,"xl/worksheets/sheet1.xml",sheet);}
 }
 static String fmt(double d){return String.format(java.util.Locale.US,"%.2f",d);}static void put(ZipOutputStream z,String n,String s)throws Exception{z.putNextEntry(new ZipEntry(n));z.write(s.getBytes("UTF-8"));z.closeEntry();}
}
