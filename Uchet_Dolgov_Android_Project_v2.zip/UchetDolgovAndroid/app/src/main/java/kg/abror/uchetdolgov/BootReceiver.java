package kg.abror.uchetdolgov;
import android.content.*;
import java.util.*;
public class BootReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  if(!Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()))return;
  Map<String,?> all=c.getSharedPreferences(SmsReminderReceiver.PREF,0).getAll();
  for(Map.Entry<String,?> e:all.entrySet())try{
   String[] v=String.valueOf(e.getValue()).split("\\n",3);
   if(v.length==3) SmsReminderReceiver.schedule(c,e.getKey(),v[0],Long.parseLong(v[1]),v[2]);
  }catch(Exception ignored){}
 }
}
